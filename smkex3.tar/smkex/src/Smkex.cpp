#include "MpMsg.h"
#include "MpIMsg.h"
#include "MpBaseService.h"
#include "MpStatus.h"
#include <iostream>
#include<string.h>
#include<cstring>
#include "Smkex.h"
#include<vector>
#include <map>
#include<algorithm>			
#include <openssl/ecdh.h>   //de exemplu pentru create common key
#include <time.h>
#include"smkexrecord.h"
#include "SmkexSessionInfo.h"  
#include "Smkex.h"
#include "crypto.h"
#define THIS_TAG "Smkex"
using namespace std;

map<MpString,SmkexSessionInfo*> Smkex::smkexKeychain;
MpString Smkex::myself;

SmkexSessionInfo* Smkex::getSessionInfo(MpString buddy){
  if (Smkex::hasSessionInfo(buddy))
	return (SmkexSessionInfo *) Smkex::smkexKeychain.find(buddy)->second;
  else return NULL;
}

int Smkex::addSessionInfo(MpString buddy,SmkexSessionInfo *sessionInfo, int force){
	if(force==1){
		Smkex::smkexKeychain.insert(std::pair<MpString,SmkexSessionInfo*>(buddy,sessionInfo));
	}
	//TODO return values to tell more info
	return 1; // means successful
}


int Smkex::hasSessionInfo(MpString buddy){
   	if(Smkex::smkexKeychain.find(buddy)==Smkex::smkexKeychain.end())
		return 0;
	else
		return 1;
}

// TODO Smkex::deleteSessionInfo



Smkex::Smkex(){
	MpService::instance()->getLogger()->print(THIS_TAG, __FUNCTION__,
			" Smkex:Ctor");
}

Smkex::~Smkex() {
	MpService::instance()->getLogger()->print(THIS_TAG, __FUNCTION__,
			" Smkex:Dtor");
}

void Smkex::onSendMsgDone(void* msgId, mp_status_t xferStatus) {
	MpService::instance()->getLogger()->print(THIS_TAG, __FUNCTION__,
			"Message xfer done...");
	std::cout << "Message xfer status:";
	if (xferStatus == MP_MESSAGE_SENT) {
		cout << " Smkex:OK!" << std::endl;
	} else {
		std::cout << " Smkex:NOT OK!" << std::endl;
	}
}

unsigned char *Smkex::storeKeyOrNonce(unsigned char *pointer, unsigned int length){
	unsigned char *ptr=(unsigned char *) malloc(length);
	memcpy(ptr,pointer,length); // copy the key or nonce into the allocated memory region
	cout<<"Smkex::storeKeyOrNonce: stored the following key or nonce: returning a pointer to it: \n";
	print_key(ptr,length);
	return ptr;
}

int Smkex::sendKeyOrNonce(unsigned char *pointer, unsigned int length, MpString buddy, int chan){
	if(pointer==0){
		cout<<" Smkex::sendKeyOrNonce: encountered nullpointer as parameter\nreturning 0 \n\n";
		return 0; // 
	}
	cout<<"Smkex::sendKeyOrNonce: sending key or nonce:\n";
	Smkex::print_key(pointer,length);
    MpBuffer payloadSmkex((uint8_t*) pointer, length);
	MpMsgPayload messageSmkex(buddy, payloadSmkex, 1, 5, 1, /*int creationDate,*/ MP_TYPE_MESSAGE, false);
	MpService::instance()->getAutoResend()->addMessage(messageSmkex);
	return 1; // seems successful
}


void Smkex::makeNonce(unsigned char *nonce, unsigned int nonce_length){
	if(RAND_bytes(nonce,(size_t)nonce_length)==0){
		cout<<"Smkex.cpp::makeNonce: Error creating nonce...............\nExiting\n";
		exit(1);
	}
	else{
		cout<<"Smkex.cpp::makeNonce: Successfully created local nonce\n";
		Smkex::print_key(nonce,nonce_length);
		//exit(1);
	}

}


// TODO SMKEX next
// Calculate common key
// make IV
// possibly also: check compatibility of the way DH keys are created with the rest of the strategy (other program creates DH EC keys)


int Smkex::initSession(MpString buddy){ // is called now from MpMain , TODO Liliana use function makeNonce instead
	// make local nonce 
	unsigned char *nonce= (unsigned char *) malloc(SESSION_NONCE_LENGTH);
	if(RAND_bytes(nonce,SESSION_NONCE_LENGTH)==0){
		cout<<"Smkex.cpp::initSession: Error creating nonce...............\nExiting\n";
		exit(1);
	}
	else{
		cout<<"Smkex.cpp::initSession: Successfully created local nonce\n";
	}


	if (!Smkex::hasSessionInfo(buddy)){
		SmkexSessionInfo *session= new SmkexSessionInfo();
		session->iAmSessionInitiator=1;
		addSessionInfo(buddy,session,1);
		// now record local nonce and store it in the SessionInfo
		// also record value for local_nonce_length
		session->local_nonce=nonce;
		session->local_nonce_length=SESSION_NONCE_LENGTH;
		cout<<"Initiating SMKEX session: sending public key to buddy (on channel 1)\n\n";
		print_key(session->local_pub_key, session->local_pub_key_length);
		
		SmkexT4mRecord *rec= getSmkexT4mRecord2(0,buddy,Smkex::getClientId(), handshake, SMKEX_T4M_PROTOCOL_VERSION, session->local_pub_key_length,session->local_pub_key);
		printRecord(rec);
		//cout<<"Smkex::initSession: Testing serialization on actual record, and exiting now due to test\n";
		//exit(1);
		unsigned int len; // now serialize
		unsigned char *recordSerial=SerializeSmkexT4mRecord(&len,rec);
		sendKeyOrNonce(recordSerial,len, buddy,1);
		
		cout<<"\n\nNow sending nonce_init to buddy (on channel 2):\n";
		sendKeyOrNonce(session->local_nonce,session->local_nonce_length,buddy,2);
		print_key(session->local_nonce,session->local_nonce_length);
		// update status to waitKeyNonceHDest 
		session->status=waitKeyNonceHDest;
	}
	else{
		SmkexSessionInfo *session=getSessionInfo(buddy);
		session->iAmSessionInitiator=1;
		if(session->status!=waitKeyNonceHDest){
			session->local_nonce=nonce;
			session->local_nonce_length=SESSION_NONCE_LENGTH;
			cout<<"\n\n\n \nInitiating SMKEX session: sending public key to buddy (on channel 1)\n\n\n";
			SmkexT4mRecord *rec= getSmkexT4mRecord2(0,buddy,Smkex::getClientId(), handshakeKey, SMKEX_T4M_PROTOCOL_VERSION, session->local_pub_key_length,session->local_pub_key);
			printRecord(rec);
			cout<<"Smkex::initSession: Testing serialization on actual record, and exiting now due to test\n";
			//exit(1);
			unsigned int len; // now serialize
			unsigned char *recordSerial=SerializeSmkexT4mRecord(&len,rec);
			sendKeyOrNonce(recordSerial,len, buddy,1);
			//sendKeyOrNonce(session->local_pub_key,session->local_pub_key_length, buddy,1);
			cout<<"\n\n\n\n\nNow sending nonce_init to buddy (on channel 2):\n\n\n";
			free(rec);
			rec= getSmkexT4mRecord2(0,buddy,Smkex::getClientId(), handshakeNonce, SMKEX_T4M_PROTOCOL_VERSION, session->local_nonce_length,session->local_nonce);
			free(recordSerial);
			recordSerial=SerializeSmkexT4mRecord(&len,rec);
			sendKeyOrNonce(recordSerial,len, buddy,1);
			session->status=waitKeyNonceHDest;
		}
	}
	cout<<"Smkex.cpp::initSession:with buddy "<<  buddy <<" the nonce is \n";
	print_key(getSessionInfo(buddy)->local_nonce ,SESSION_NONCE_LENGTH);

	cout<<"Smkex.cpp::initSession:with buddy "<<  buddy <<" finished\n";
	//exit(1);
	return 1; // means OK
}

/* 
 * Computes the session info for SMKEX. Basically a SHA256 of key1/nonce1/key2/nonce2.
 * The result is the SHA256 char string.
 *
 * Input Parameters:
 *  @resultLength: a pointer to an integer, where the output length of the hash will be stored
 *  @key1: the sender's (EC)DH public key
 *  @nonce1: the sender's nonce
 *  @key2: the receiver's (EC)DH public key
 *  @nonce2: the receiver's nonce
 *
 * @Returns: the Hash result
 */
unsigned char *Smkex::calculateH(unsigned int *resultLength, const char *key1, const char *nonce1, const char *key2, const char * nonce2, unsigned int nonce_length, unsigned int key_length){
 	unsigned char *resultH;
  const EVP_MD *md = EVP_sha256();
  EVP_MD_CTX *mdctx;
  //unsigned char md_value[EVP_MAX_MD_SIZE];

  *resultLength = 0;
  if (nonce_length <=0)
    return NULL;
  if (key_length <=0)
    return NULL;

	resultH=(unsigned char *) malloc(EVP_MAX_MD_SIZE);
  mdctx = EVP_MD_CTX_new();
  EVP_DigestInit_ex(mdctx, md, NULL);
  EVP_DigestUpdate(mdctx, nonce1, strlen(nonce1));
  EVP_DigestUpdate(mdctx, key1, strlen(key1));
  EVP_DigestUpdate(mdctx, nonce2, strlen(nonce2));
  EVP_DigestUpdate(mdctx, key2, strlen(key2));
  EVP_DigestFinal_ex(mdctx, resultH, resultLength);
  EVP_MD_CTX_free(mdctx);

  return resultH;
}

// TODO Marios
int Smkex::verfiyH(unsigned char *receivedHValue, size_t receivedHLength, unsigned char *nonce1, unsigned char *key1, unsigned char *nonce2,unsigned char *key2, size_t nonce_length, size_t key_length){ 
  // daca mai este necesar pot fi adaugati si alti parametri ai functiei
  // returneaza 1 daca s-a verificat valoarea lui H ca fiind corecta si 0 daca nu a fost verificata
	return 1; // daca e verificat cu succes return 1 else return 0 
}



// TODO not working
int Smkex::computeAndStoreSessionKey(SmkexSessionInfo *session,MpString const& buddy){
	// EC_KEY TEST	
	EC_KEY *key= __new_key_pair();	
	const EC_GROUP* ec_group = EC_KEY_get0_group(key);
    const EC_POINT* ec_pub_key	 = EC_KEY_get0_public_key(key);
  	// const EC_POINT* ec_priv_key = EC_KEY_get0_private_key(key);
    // Compute size of public key byte representation
    size_t pub_key_size = EC_POINT_point2oct(ec_group, ec_pub_key,
            POINT_CONVERSION_UNCOMPRESSED, NULL, 0, NULL);  // get required size first
	unsigned char * localPublicKey=(unsigned char *)malloc(pub_key_size);
	size_t pub_key_size2=EC_POINT_point2oct(ec_group, ec_pub_key,
            POINT_CONVERSION_UNCOMPRESSED, localPublicKey, pub_key_size, NULL); 
    if (pub_key_size == 0) {
        fprintf(stderr, "Error: Could not compute ECDH exchange length.\n");
        return -1;
    }
	else 
	{
		cout<< "size of public key: "<< pub_key_size <<" now printing the resulting key\n"; // iese 65, in mod consistent
		print_key(localPublicKey,pub_key_size);

	}
   
	// NOW RETRIEVE EC_POINT FROM first PUBLIC KEY (using  a different created key pair)
	// STRATEGY SEE INITIAL PROGRAM

	EC_KEY *key2= __new_key_pair();	// creating a key pair where the previous public key is set
	const EC_GROUP* ec_group2 = EC_KEY_get0_group(key2); 
	EC_POINT * remote_pub_key_point = EC_POINT_new(ec_group2); // allocate place for a new point for remote public key 
	int q=EC_POINT_oct2point(ec_group,remote_pub_key_point,localPublicKey,pub_key_size,NULL);
	if (q==0){
		cout<<"Error converting public key to point\n";
		exit(1);
	}
	else{
		cout<<"success: obtained a EC_POINT from string pertaining to previously generated public key\n";
	}

	// now get back the char sequence for the point to make sure it fits with the original
	pub_key_size = EC_POINT_point2oct(ec_group2, remote_pub_key_point,
            POINT_CONVERSION_UNCOMPRESSED, NULL, 0, NULL);
	EC_POINT_point2oct(ec_group2, remote_pub_key_point,
            POINT_CONVERSION_UNCOMPRESSED, localPublicKey, pub_key_size, NULL); 
	if (pub_key_size == 0) {
        fprintf(stderr, "Error: Could not compute ECDH exchange length.\n");
        return -1;
    }
	else 
	{
		cout<< "After trying to retrieve public key using ec group from new key pair\n size of newly produced key: "<< pub_key_size <<"; now printing the resulting key:\n"; // iese 65, in mod consistent
		print_key(localPublicKey,pub_key_size);

	}

	// now compute private key:
	const BIGNUM *priv_key_num = EC_KEY_get0_private_key(key);
	unsigned int priv_key_len= BN_num_bytes(priv_key_num);
	unsigned char *priv_key = (unsigned char *) malloc(BN_num_bytes(priv_key_num)); // what is the size here?
	BN_bn2bin(priv_key_num, priv_key); 
	cout<<"Smkex::storeKeyOrNonce: possibly useful for key storage: converted private key with length "<< priv_key_len<<" to unsigned char *\nPrinting it now:\n";
	print_key(priv_key,BN_num_bytes(priv_key_num)); 
	cout <<" now convert private key back to Bignum and then to EC_KEY (useful for EC_KEY retrieval) (TODO)\n";

	/*BIGNUM *privKeyNumCopy;
	BIGNUM *x= BN_bin2bn(priv_key, priv_key_len, privKeyNumCopy);
	if (privKeyNumCopy==0){
		cout<<"Could not convert\n";
	}
	else{
		cout<<"conversion seems successful, checking that the resulting stding is the same: \n";
		BN_bn2bin(privKeyNumCopy, priv_key);
		print_key(priv_key,priv_key_len); 

	}*/


	cout <<" Smkex::storeKeyOrNonce: use entities (currently for now form this one key pair) to create a secret key; it has length 64\n";


 	int rc_dummy = ECDH_compute_key(session->session_key, KDF_KEY_LENGTH, (const EC_POINT*) ec_pub_key, (const EC_KEY*) 
						key, nist_800_kdf); 	

	print_key(session->session_key, 64);
    // sugestie web de lucru cu cheile https://stackoverflow.com/questions/58832662/elliptic-curve-diffie-hellman-public-key-size

	//EC_POINT pub_key_point=EC_POINT_oct2point(




//	cout<< "Smkex::computeAndStoreSessionKey: remote pub key is:\n";
//	print_key(session->remote_pub_key, session->remote_pub_key_length);
//	cout<< "Smkex::computeAndStoreSessionKey: private  key is:\n";
//	print_key(session->local_priv_key, session->local_pub_key_length);
	/*
	int rc = ECDH_compute_key(session->session_key, KDF_KEY_LENGTH, (const EC_POINT*) session->remote_pub_key, (const EC_KEY*) 
						session->local_priv_key, nist_800_kdf); 
	if(rc==-1){
			cout<< "Smkex::computeAndStoreSessionKey: \n";
			cout<<"error computing key for session with "<< buddy <<"\n";
			exit(1);	
			return -1;
	}
	cout<< "Smkex::computeAndStoreSessionKey: printing key: \n";
	//print_key(session->session_key,KDF_KEY_LENGTH);
	//	exit(1); 
	*/
	exit(1);
	return 1;
}



int Smkex::processSmkexMessageSip(unsigned char * msg, uint32_t msgLen, MpString const& buddy){
	SmkexT4mRecord *rec=getRecordFromSerial((unsigned char *)(msg+1));
	if(rec==0)
		return 0; 
	printRecord(rec);
	cout<<"searching for  session info for buddy   "<<buddy<<"\n\n";
	SmkexSessionInfo *session;
	if(hasSessionInfo(buddy)){
		cout<<"we found a session info for buddy   "<<buddy<<"\n\n";
		session=getSessionInfo(buddy);
		cout<<"we retrieved  a session info for buddy   "<<buddy<<" and the public key for dan is:\n\n";
		print_key(session->local_pub_key,session->local_pub_key_length);
	}	
	else{
		session=new SmkexSessionInfo();  	
		// add buddy and sessioninfo to keychain, set status to not connected, and that the user is not initiator 
		Smkex::addSessionInfo(buddy,session,1);
	}

	switch((int)rec->type){
		case handshakeKey:
			cout<<"Smkex::processSmkexMsgSip: received handshakeKey\n";
			switch(session->status){ // maybe eliminate all wrong states and send an error message first??
				case notConnected:
					cout<<"Smkex::processSmkexMsgSip: status is notConnected\n";
					memcpy(session->remote_pub_key,rec->data,PUB_KEY_LEN);
					//send my public Key
					if(computeAndStoreSessionKey(session,buddy)){
						cout<<"Smkex::processSmkexMsgSip: comouted session key\n";
						print_key(session->session_key,KDF_KEY_LENGTH);
						exit(1);
					}
					session->status=waitNonceInit;
					break;
				case waitKeyNonceHDest:
				    memcpy(session->remote_pub_key,rec->data,PUB_KEY_LEN);
					computeAndStoreSessionKey(session,buddy);
					session->status=waitNonceHDest;
					break;
				case waitKeyDest:{
					memcpy(session->remote_pub_key,rec->data,PUB_KEY_LEN);
					computeAndStoreSessionKey(session,buddy);
					int verifyH=0;  // DUMMY for now	
					if(verifyH)
					  session->status=connected;
					else{
						session->status=notConnected;
						sendAlert(buddy);// send an error message
					}
				}
				break; 
				case connected:
					memcpy(session->remote_pub_key,rec->data,PUB_KEY_LEN);
					session->status=waitNonceInit;
					break;  // reset session and expect the other to be initiator in the next round
					// TODO discuss whether OK / could also ignore since the message is out of place, I prefer the implemented choice		
				//default:
				//	sendAlert(buddy);						

			}
			break; 
		case handshakeNonce:
			cout<<"Smkex::processSmkexMsgSip: received handshakeNonce\n";
			switch(session->status){
				case waitNonceInit:
					memcpy(session->remote_nonce,rec->data,NONCE_LEN);
					session->status=waitNonce2HInit;
					break;
				case waitKeyNonceHDest:
					memcpy(session->remote_nonce,rec->data,NONCE_LEN);
					session->status=waitKeyDest;
					break;
				case connected:
					memcpy(session->remote_nonce,rec->data,NONCE_LEN);
					session->status=waitKeyInit; // TODO discuss
					break;
				//default:
				//	sendAlert(buddy);
				//	session->status=notConnected;
				}
			break; 
		case handshakeNonceH:  // todo: first verify the
			break;
		case handshakeH:       // todo
			break;
		case alert:
			session->status=notConnected;
			if (session->iAmSessionInitiator)
				Smkex::initSession(buddy);
			break;

	}


	cout<<"Smkex::processSmkexMessageSip: returning\n\n";
	//exit(1);
	return 1;
}

void Smkex::sendAlert(MpString const& buddy){
	cout<<"sending alert, connection with buddy" <<buddy <<" could not be established \n";
	unsigned char a[2]="a"; // dummy data included (esle functions would need updating)
	SmkexT4mRecord *rec= getSmkexT4mRecord2(0,buddy,Smkex::getClientId(), alert, SMKEX_T4M_PROTOCOL_VERSION,2,a); 
	printRecord(rec);
	unsigned int len; // now serialize
	unsigned char *recordSerial=SerializeSmkexT4mRecord(&len,rec);
	sendKeyOrNonce(recordSerial,len, buddy,1);
}

void Smkex::onMsgReceived(MpString const& serial, const uint8_t* msg, uint32_t msgLen) {  // aici e aplicatia layer de sus, serial este id celelalt
	
	MpService::instance()->getLogger()->print(THIS_TAG, __FUNCTION__,
											  "Smkex:Message received...");
    //exit(1);

	std::cout << "\n\n\n\n\n         Smkex: Message from:" << serial << std::endl;
	std::cout << "      Smkex: Message length:" << msgLen << std::endl;

	std::string message((char *)msg,msgLen); //msg  nu e null-terminated	extragem mesajul din ce a venit

	std::cout << "      Smkex: Message (read as char*) is exactly ----" <<message<<  "---- and its length is ---"<<msgLen<<"---\n\n\n\n\n";  

	unsigned char *msgCpy=(unsigned char *)malloc(msgLen+1);
	memcpy(msgCpy,msg,msgLen+1);
	SmkexT4mRecord *rec=getRecordFromSerial((unsigned char *)(msg+1));
	printRecord(rec);
	Smkex::processSmkexMessageSip(msgCpy,msgLen,serial);

	cout<<"returning from function onMsgReceived\n\n\n";	

	return; // we called the other function the next things are not necessary for now
	
	if(msgLen==SESSION_NONCE_LENGTH+1 || msgLen==SESSION_NONCE_LENGTH){
		// it is likely a nonce
		SmkexSessionInfo *session;
		if(hasSessionInfo(serial))
			session=getSessionInfo(serial);
		else{
			SmkexSessionInfo session__=SmkexSessionInfo();
			session=&session__;
			addSessionInfo(serial,session,1);
		}
		MpString buddy=MpString(serial);
		switch(session->status){
			case notConnected:
				// store nonce and send local public Key on channel 1
				session->remote_nonce=storeKeyOrNonce((unsigned char *)msg+1,SESSION_NONCE_LENGTH);
				session->remote_nonce_length=SESSION_NONCE_LENGTH;
				sendKeyOrNonce(session->local_pub_key,session->local_pub_key_length,buddy,1);
				session->iAmSessionInitiator=0;
				session->status=waitKeyInit;
				break;
			case waitNonceInit:
				session->remote_nonce=storeKeyOrNonce((unsigned char *)msg+1,SESSION_NONCE_LENGTH);
				session->remote_nonce_length=SESSION_NONCE_LENGTH;
				// make my nonce, calculate H and send the nonce and the H (separate messages?)
				session->local_nonce=(unsigned char *) malloc(SESSION_NONCE_LENGTH);
				/*if(!RAND_bytes(session->local_nonce,SESSION_NONCE_LENGTH)==0){
					cout<<"Smkex.cpp: onMsgReceived: processing a possible received nonce: could not create nonce; exiting.......\n";
					exit(1);
				}*/
				makeNonce(session->local_nonce,session->local_nonce_length);
				// Now Compute COmmon Key 
				//unsigned char *rc=(unsigned char *)malloc(256);
				/*int rc = ECDH_compute_key(session->session_key, KDF_KEY_LENGTH,
            (const EC_POINT*) session->remote_pub_key, (const EC_KEY*) session->local_priv_key, nist_800_kdf); // verify ec_key= local_private_key
 				*/

				unsigned char *hValue;
				unsigned int hValueLength=0;

				//TODO change if assumption that all nonces have the same length and all public keys also have the same length
				hValue=calculateH(&hValueLength, (char*)session->remote_pub_key, (char*)session->remote_nonce, (char*)session->local_pub_key, (char*)session->local_nonce,session->local_nonce_length,session->local_pub_key_length);
						
				unsigned char *smkexMessage= (unsigned char *)malloc(SESSION_NONCE_LENGTH+hValueLength);
				// create an Smkex message that contains the nonce and the value of H
				memcpy(smkexMessage,session->local_nonce,SESSION_NONCE_LENGTH);
				memcpy(smkexMessage+SESSION_NONCE_LENGTH, hValue, hValueLength);
				cout<<"Sending Smkex message containing nonce and H value as follows:\n";
				print_key(smkexMessage,hValueLength+SESSION_NONCE_LENGTH);
				cout<<"To verify the nonce is:\n";
				print_key(session->local_nonce,SESSION_NONCE_LENGTH);	
				// now send nonce and H value in one message
				sendKeyOrNonce(smkexMessage,SESSION_NONCE_LENGTH+hValueLength,buddy,2);
				//exit(1);	
				//TODO Liliana free(smkexMessage); (does the SIP free the message by itself after sending it, seems so ..)
				session->iAmSessionInitiator=0;
				session->status=waitNonce2HInit;
				break;
			//default:
			//	"Received a possible nonce but did not recognize an adequate state\n Processing SMKEX messages might also not be fully implemented at this point\n";
			//	exit(1);
		}

	}



	if(msgLen==257){ // it is likely a key
		cout<<"\n\n\n\n(still testing) Received possible key: it transmits (or prints) 2 zeroes more than were in the original key if starting to print with msg[0]\nPrinting from k=1 until k<msgLen\n";
		cout<<"Message length msglen is "<<msgLen<<" and thus subtracting 1 gives us the correct key length 256\n\n";
		for (unsigned int k=1; k < msgLen;k++){
			printf("%02X",msg[k]);
		}
		cout<<"\n\n";

		// Testing of functions storeKeyOrNonce and sendKeyOrNonce before implementing state machine

		if(Smkex::smkexKeychain.find(serial)!=Smkex::smkexKeychain.end()){ 
			cout<<"We found a session\n\n\n";

			SmkexSessionInfo *session=Smkex::smkexKeychain.find(serial)->second;
			if(session->remote_pub_key==0){
				session->remote_pub_key=Smkex::storeKeyOrNonce((unsigned char *)msg+1, (unsigned int) msgLen -1);
				cout<<"\nSmkex::onMsgReceived: checking storage of received public key in sessionInfo\n\n";
				print_key(session->remote_pub_key,msgLen-1);
				cout<<"\nSmkex::onMsgReceived: checking storage of received public key in sessionInfo retrieved from keyChain\n\n";
				print_key(Smkex::smkexKeychain.find(serial)->second->remote_pub_key,msgLen-1);
				cout<<"\nSmkex::onMsgReceived: now send my local public key to "<< serial<<" \n\n\n";
				if(Smkex::sendKeyOrNonce(session->local_pub_key, session->local_pub_key_length,serial,1))
					cout<<"\nSmkex::onMsgReceived: sent local public key to "<< serial<<" \n\n\n";

				//exit(1);	
			}
		}





		if(Smkex::smkexKeychain.find(serial)==Smkex::smkexKeychain.end()){ // there is no session info for this buddy yet
		

			cout<<"There is no SMKEX session with buddy "<<serial<<"  producing sessioninfo now \n\n\n";
			//exit(1);
		
			SmkexSessionInfo sessionInfo=SmkexSessionInfo();  // the constructor creates DH public and private 
			sessionInfo.remote_pub_key=Smkex::storeKeyOrNonce((unsigned char *)(msg+1),msgLen-1);
			sessionInfo.status=1; // received the first transmission (of the remote public key)
            sessionInfo.remote_pub_key_length=msgLen-1;
			Smkex::smkexKeychain.insert(std::pair<MpString,SmkexSessionInfo*>(serial,&sessionInfo));
			

			cout<<"\n\nSMKEX key exchange: \nSending my public Key after receiving public key from "<< serial  << " \n\n";
		
			unsigned char *smkex_key=    sessionInfo.local_pub_key;

			// verifying that the local public key was stored correctly 
			//cout<< "SMKEX key is "<<

            MpBuffer payloadSmkex1((uint8_t*) smkex_key,sessionInfo.local_pub_key_length) ;
			MpMsgPayload messageSmkex0(serial, payloadSmkex1, 1, 5, 1, /*int creationDate,*/ MP_TYPE_MESSAGE, false);
			MpService::instance()->getAutoResend()->addMessage(messageSmkex0);
		}
		else if(Smkex::smkexKeychain[serial]->status==0){
			SmkexSessionInfo *sInfo=Smkex::smkexKeychain[serial];
			sInfo->remote_pub_key=(unsigned char *)(msg+1);
			sInfo->remote_pub_key_length=msgLen-1;
			sInfo->status=2;  // I have sent my public key and received the remote public key
		}


	}











//Initial debug and testing: Dorim raspuns: send confirmation: conf: I hereby confirm receiving message: 
   
	size_t pos= message.find("This");
	if(message.find("This")!=string::npos)
		cout <<"\n\n\n     Smkex: found substring \"This\" in the message " << message<<" at position "<< pos<<"\n\n\n";
	else{

		cout <<"\n\n\n     Smkex: did not find substring \"This\" in the message " << message;

	} 	
	/*pos= message.find(" Smkex:Please start SMKEX");
	if(pos!=string::npos){
		cout <<"\n\n\n Smkex: found substring \"Please start SMKEX\" in the message " << message<<" at position "<< pos<<"\n\n\n";
		//exit(1); 
	}
	else{

		cout <<"\n\n\n  Smkex: did not find substring \"Please start SMKEX\" in the message " << message;

	} */	
    pos= message.find("Hello");
	if(message.find("Hello")!=string::npos){
		cout <<"\n\n\n  Smkex: found substring \"Hello\" in the message " << message<<" at position "<< pos<<"\n\n\n";
		string restMessage= message.substr(strlen("Hello")+1, message.length() - strlen("Hello"));
		cout<<" Smkex: besides \"Hello\" the message contains the following character sequence: --->"<<restMessage<<"<---\n\n\n";
		

	}
	else{

		cout <<"\n\n\n  Smkex:did not find substring \"Hello\" in the message " << message;

	} 	



   // debug and testing; confirming receipt of a message unless the received message is not a confirmation
   if(message.find("xconf")!=string::npos){
	   cout<< "\n\n\n  Smkex: received the following confirmation message: "<< message<<"\n\n\n";
	   cout<<"  Smkex: and the position of xconf is "<< message.find("xconf")<<"\n\n";
	  // exit(1);
   }
   else{
       char *msgPayload = (char *)malloc(25);
	   strcpy(msgPayload, "xconf received your message: ");
	    
	  /* int n = message.length();
       char char_array[n + 1];
       strcpy(char_array, message.c_str());
	   cout<<"made a cstring:"<< char_array;*/
	   string check_message(msgPayload);
	   cout<<"\n Smkex: confirmation message sent: "<<check_message << " and the position of xconf is "<< check_message.find("xconf")<<" \n\n"
	   <<""; 
		//exit(1); 	
  

       MpBuffer payload((uint8_t*) msgPayload, strlen(msgPayload)+1);
	   // mesajul a venit de la serial


       MpMsgPayload message(serial, payload, 1, 5, 1, /*int creationDate,*/ MP_TYPE_MESSAGE, false);
       MpService::instance()->getAutoResend()->addMessage(message);
   } 

  /* aici sau intr-un loc similar in clasa SMKEX va avea loc decriptarea mesajelor
 
	TODO
	cu cheia schimbata tot prin mesaje text 
	unde salvam datele pentru decriptare ? un MariaDB
	de unde stim ca ce am primit sunt date pentru decriptare (deducem din ordinea mesajelor, respectiv programam intr-un anumit fel) ?
	

	*/ 


     
}



void Smkex::print_key(unsigned char *key, int n){
   for(int k=0; k<n; k++)
        printf("%02X", key[k]);
   printf("\n");	
}


void Smkex::testRecord(const MpString buddy, MpString myself, SmkexSessionInfo *session){
	cout<<"\n\n\n\nSmkex::testRecord \n\n\n\n";
	time_t timestamp=time(NULL);
	cout<<ctime(&timestamp)<<"\n";

	int64_t timestampInt=(int64_t)timestamp;


	cout<<"Size of timestampInt: "<< sizeof(timestampInt);
	cout<<"timestamp as int:" << (int64_t)timestampInt <<"\n";
	time_t timestamp2=(time_t) (timestampInt);
	cout<<"converted from int_64 this is:"<<ctime((const time_t*)&timestamp2)<<"\n";
	// converting time back and forth works nicely

	cout <<"buddy is: " << buddy <<"\n\n";
	cout<< "my id is: "<< myself << "\n\n";

	SmkexT4mRecord * rec= new SmkexT4mRecord;	

	rec->timestamp=timestampInt;
	rec->destLen=(uint16_t)buddy.length()+1;
	rec->dest=(unsigned char *) malloc(rec->destLen);
	memcpy(rec->dest,buddy.c_str(),rec->destLen);
	std::string dest=std::string((char *)rec->dest,rec->destLen);
	cout<<"rec->dest:"<<rec->dest<< "\n";
	cout<<"destestLen="<<rec->destLen<<"\n";
	rec->senderLen= (uint16_t)myself.length()+1;  // including the \0 at the end of the string
	rec->sender=(unsigned char *)malloc(rec->senderLen);
	memcpy(rec->sender,myself.c_str(),rec->senderLen);
	cout<<"senderLen:"<<rec->senderLen<<"\n";
	rec->version=SMKEX_T4M_PROTOCOL_VERSION;
	rec->type=handshake; // to insert type here
	rec->length=session->local_pub_key_length;
	rec->data= (unsigned char *) malloc(rec->length);
	memcpy(rec->data,session->local_pub_key,rec->length);
	print_key(rec->data,(int)rec->length);
	// (record created: OK)


	unsigned int len=0;
	//make serialized record
	unsigned char *serialRec= SerializeSmkexT4mRecord(&len, rec);
	// now extract the data out of the serialized record

	SmkexT4mRecord *rec2=getRecordFromSerial(serialRec);

	printRecord(rec2);	

	

}



void Smkex::setClientId(MpString clientId){
	Smkex::myself=MpString(clientId);
}
	
	
MpString  Smkex::getClientId(){
	return myself;

};


void Smkex::testCryptography(){
	// make two keys a,d 


}